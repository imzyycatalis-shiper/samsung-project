# SAMSUNG PROJECT GAME TURBO v3.0 — IMZYY KNOX (Native, tanpa WebView)

## FPS Control (refresh rate nyata, tanpa root)
- Tombol 10 / 30 / 60 / 90 / MAX di app dan di floating hub
- MAX = refresh rate tertinggi yang didukung layar perangkat (misal 90/120 Hz)
- Memakai izin "Ubah setelan sistem" (peak/min refresh rate) + preferred display mode untuk jendela app/overlay
- Hasil diverifikasi: app membaca Hz layar yang benar-benar berjalan dan menampilkan LIVE Hz
- Layar Samsung tidak punya mode 10/30 Hz, jadi 10 dan 30 dikunci ke mode terendah layar
- Jika One UI menimpa, atur juga Display > Kehalusan gerakan (tombol MOTION SETTINGS)

## Fitur lain
TURBO BOOST, CLEAN RAM, CLEAR CACHE, live RAM/storage/baterai/suhu/thermal, device scanner,
floating hub (bubble draggable, DND, AWAKE, MAX BRIGHT, PING).

## Batasan jujur
Aplikasi biasa tidak bisa memaksa FPS di dalam game lain, mengubah clock CPU/GPU, atau governor tanpa root/privilege sistem.
