package com.imzyyknox.gameturbo;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int CY = 0xFF53E9FF, BL = 0xFF3C86FF, PU = 0xFF9270FF, OK = 0xFF55E7A9, WARN = 0xFFFFC857, BAD = 0xFFFF6B6B, MUTE = 0xFF8394A9;
    private static final int[] TARGETS = {10, 30, 60, 90, 0};
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final FpsEngine.Meter meter = new FpsEngine.Meter();
    private final ArrayList<TextView> fpsBtns = new ArrayList<>();
    private SharedPreferences sp;
    private TextView tRam, tSto, tBat, tTemp, tTherm, tHz, liveHz, fpsStatus, boostStatus;
    private final Runnable tick = new Runnable() { public void run() { refresh(); ui.postDelayed(this, 2000); } };

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int c1, int c2, int r, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(r)); if (stroke != 0) g.setStroke(dp(1), stroke); return g;
    }
    private TextView txt(String s, int sz, int c, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sz); t.setTextColor(c);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD); return t;
    }
    private LinearLayout row() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }
    private LinearLayout.LayoutParams mt(int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); return p; }
    private LinearLayout.LayoutParams w1(boolean first) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (!first) p.leftMargin = dp(8); return p; }
    private LinearLayout card(LinearLayout col, String title, String sub) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(14), dp(16), dp(16));
        c.setBackground(bg(0xFF0E1A28, 0xFF080D14, 20, 0x3353E9FF));
        LinearLayout h = row();
        TextView t = txt(title, 13, 0xFFFFFFFF, true); t.setLetterSpacing(.08f);
        TextView s = txt(sub, 8, MUTE, false); s.setLetterSpacing(.12f);
        h.addView(t, new LinearLayout.LayoutParams(0, -2, 1)); h.addView(s);
        c.addView(h); col.addView(c, mt(12)); return c;
    }
    private TextView tile(LinearLayout r, String label, boolean first) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(0, dp(10), 0, dp(10));
        c.setBackground(bg(0xFF0D1723, 0xFF08121C, 14, 0x2253E9FF));
        TextView l = txt(label, 8, MUTE, false); l.setLetterSpacing(.12f);
        TextView v = txt("--", 16, 0xFFFFFFFF, true);
        c.addView(l); c.addView(v); r.addView(c, w1(first)); return v;
    }
    private TextView btn(LinearLayout r, String s, boolean first, Runnable a) {
        TextView t = txt(s, 11, 0xFFBFF8FF, true); t.setGravity(Gravity.CENTER); t.setPadding(dp(4), dp(13), dp(4), dp(13));
        t.setBackground(bg(0xFF12344B, 0xFF102140, 14, 0x4453E9FF)); t.setOnClickListener(v -> a.run());
        r.addView(t, w1(first)); return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("turbo", MODE_PRIVATE);
        final int bgc = Color.rgb(5, 8, 13);
        getWindow().setStatusBarColor(bgc); getWindow().setNavigationBarColor(bgc);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(bgc); sv.setFillViewport(true);
        sv.setOnApplyWindowInsetsListener((v, in) -> {
            v.setPadding(in.getSystemWindowInsetLeft(), in.getSystemWindowInsetTop(), in.getSystemWindowInsetRight(), in.getSystemWindowInsetBottom());
            return in;
        });
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(col);

        // Header
        LinearLayout head = row();
        TextView logo = txt("IK", 16, CY, true); logo.setGravity(Gravity.CENTER); logo.setBackground(bg(0xFF102A40, 0xFF07101A, 14, 0x6648DFFF));
        head.addView(logo, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout ti = new LinearLayout(this); ti.setOrientation(LinearLayout.VERTICAL); ti.setPadding(dp(12), 0, 0, 0);
        TextView n1 = txt("IMZYY KNOX", 14, 0xFFFFFFFF, true); n1.setLetterSpacing(.14f);
        TextView n2 = txt("GAME TURBO • NATIVE v3.0", 8, MUTE, false); n2.setLetterSpacing(.16f);
        ti.addView(n1); ti.addView(n2); head.addView(ti);
        col.addView(head);

        // Hero
        LinearLayout hero = card(col, "TURBO BOOST", "RAM • CACHE");
        TextView ring = txt("⚡\nTURBO", 22, 0xFF03131C, true); ring.setGravity(Gravity.CENTER); ring.setLetterSpacing(.1f);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CY, BL, PU}); g.setShape(GradientDrawable.OVAL); g.setStroke(dp(3), 0x55FFFFFF);
        ring.setBackground(g); ring.setOnClickListener(v -> boost(0));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(150), dp(150)); rlp.gravity = Gravity.CENTER_HORIZONTAL; rlp.topMargin = dp(14);
        hero.addView(ring, rlp);
        boostStatus = txt("Tap TURBO untuk bersihkan RAM & cache", 10, MUTE, false); boostStatus.setGravity(Gravity.CENTER);
        hero.addView(boostStatus, mt(14));

        // Live stats
        LinearLayout st = card(col, "LIVE STATUS", "REAL DATA");
        LinearLayout s1 = row(); tRam = tile(s1, "RAM USED", true); tSto = tile(s1, "STORAGE", false); tBat = tile(s1, "BATTERY", false); st.addView(s1, mt(12));
        LinearLayout s2 = row(); tTemp = tile(s2, "TEMP", true); tTherm = tile(s2, "THERMAL", false); tHz = tile(s2, "DISPLAY", false); st.addView(s2, mt(8));

        // FPS
        LinearLayout fc = card(col, "FPS CONTROL", "REFRESH RATE");
        List<Integer> rates = FpsEngine.rates(this);
        StringBuilder rs = new StringBuilder();
        for (int r : rates) rs.append(rs.length() == 0 ? "" : " • ").append(r).append(" Hz");
        fc.addView(txt("Layar mendukung: " + rs, 11, 0xFFBFD3E6, false), mt(10));
        LinearLayout live = row();
        TextView ll = txt("LIVE", 9, MUTE, true); ll.setLetterSpacing(.2f);
        liveHz = txt("-- Hz", 26, CY, true);
        live.addView(ll); live.addView(liveHz); liveHz.setPadding(dp(12), 0, 0, 0);
        fc.addView(live, mt(8));
        LinearLayout fr = row();
        for (int i = 0; i < TARGETS.length; i++) {
            final int tg = TARGETS[i];
            fpsBtns.add(btn(fr, tg == 0 ? "MAX" : String.valueOf(tg), i == 0, () -> setFps(tg)));
        }
        fc.addView(fr, mt(10));
        fpsStatus = txt("Pilih target FPS. MAX = refresh rate tertinggi yang didukung layar.", 10, MUTE, false);
        fc.addView(fpsStatus, mt(10));
        LinearLayout fa = row();
        btn(fa, "RESET AUTO", true, () -> { FpsEngine.reset(this); paintFps(); fpsStatus("Dikembalikan ke otomatis", MUTE, false); });
        btn(fa, "MOTION SETTINGS", false, () -> startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        fc.addView(fa, mt(10));
        fc.addView(txt("Catatan: ini mengunci laju layar (nyata). Aplikasi tidak bisa memaksa FPS di dalam game lain tanpa root.", 9, 0xFF52667A, false), mt(10));

        // Actions
        LinearLayout ac = card(col, "TOOLS", "QUICK ACTIONS");
        LinearLayout a1 = row();
        btn(a1, "⚡ FLOATING HUB", true, this::startHub);
        btn(a1, "CLEAN RAM", false, () -> boost(1));
        ac.addView(a1, mt(12));
        LinearLayout a2 = row();
        btn(a2, "CLEAR CACHE", true, () -> boost(2));
        btn(a2, "BATTERY", false, () -> startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        ac.addView(a2, mt(8));

        // Device
        LinearLayout dc = card(col, "DEVICE", "SCANNER");
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        String soc = Build.VERSION.SDK_INT >= 31 ? Build.SOC_MODEL : Build.HARDWARE;
        String info = "Model      " + Build.MANUFACTURER + " " + Build.MODEL + "\nAndroid    " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\nChipset    " + soc
                + "\nCPU        " + Runtime.getRuntime().availableProcessors() + " cores • " + Build.SUPPORTED_ABIS[0]
                + "\nRAM        " + (Boost.mem(this).totalMem >> 20) + " MB\nLayar      " + dm.widthPixels + "×" + dm.heightPixels + " • " + dm.densityDpi + " dpi\nKernel     " + System.getProperty("os.version");
        TextView it = txt(info, 11, 0xFFBFD3E6, false); it.setTypeface(Typeface.MONOSPACE); it.setLineSpacing(0, 1.25f);
        dc.addView(it, mt(12));

        TextView foot = txt("Developed by IMZYY KNOX", 9, 0xFF52667A, false); foot.setGravity(Gravity.CENTER); foot.setLetterSpacing(.15f);
        col.addView(foot, mt(20));

        setContentView(sv);
        paintFps();
    }

    @Override protected void onResume() { super.onResume(); meter.start(liveHz); ui.post(tick); }
    @Override protected void onPause() { super.onPause(); meter.stop(); ui.removeCallbacks(tick); }

    private void fpsStatus(String s, int c, boolean unused) { fpsStatus.setText(s); fpsStatus.setTextColor(c); }
    private void paintFps() {
        int sel = sp.getInt("fps", -1);
        for (int i = 0; i < fpsBtns.size(); i++) {
            TextView t = fpsBtns.get(i); boolean on = TARGETS[i] == sel;
            t.setTextColor(on ? 0xFF03131C : 0xFFBFF8FF);
            t.setBackground(on ? bg(CY, PU, 14, 0) : bg(0xFF12344B, 0xFF102140, 14, 0x4453E9FF));
        }
    }
    private void setFps(final int target) {
        final int hz = FpsEngine.pick(this, target);
        if (!FpsEngine.apply(this, hz)) {
            fpsStatus("Izinkan 'Ubah setelan sistem', lalu tap lagi", WARN, false);
            startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            return;
        }
        sp.edit().putInt("fps", target).apply();
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        FpsEngine.prefer(lp, this, hz); getWindow().setAttributes(lp);
        paintFps(); fpsStatus("Menerapkan " + hz + " Hz…", WARN, false);
        ui.postDelayed(() -> { String m = FpsEngine.verify(this, target, hz); fpsStatus(m, m.startsWith("✓") ? OK : WARN, false); }, 900);
    }
    private void boost(final int mode) {
        boostStatus.setText("⚡ Boosting…"); boostStatus.setTextColor(WARN);
        new Thread(() -> { final String m = Boost.run(this, mode); ui.post(() -> { boostStatus.setText(m); boostStatus.setTextColor(OK); refresh(); }); }).start();
    }
    private void startHub() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan 'Tampil di atas aplikasi lain', lalu tap lagi", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } else {
            startForegroundService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Hub aktif. Tap bubble ⚡", Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }
    }
    private void refresh() {
        android.app.ActivityManager.MemoryInfo mi = Boost.mem(this);
        int used = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        tRam.setText(used + "%"); tRam.setTextColor(used > 85 ? BAD : used > 70 ? WARN : OK);
        android.os.StatFs sf = new android.os.StatFs(Environment.getDataDirectory().getPath());
        tSto.setText((sf.getAvailableBytes() >> 30) + " GB");
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            float t = b.getIntExtra("temperature", 0) / 10f;
            tBat.setText(b.getIntExtra("level", 0) * 100 / Math.max(1, b.getIntExtra("scale", 100)) + "%");
            tTemp.setText(t + "°"); tTemp.setTextColor(t >= 42 ? BAD : t >= 38 ? WARN : OK);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            int ts = ((PowerManager) getSystemService(POWER_SERVICE)).getCurrentThermalStatus();
            tTherm.setText(ts <= 0 ? "COOL" : ts == 1 ? "WARM" : ts == 2 ? "WARM+" : ts == 3 ? "HOT" : "CRIT");
            tTherm.setTextColor(ts <= 0 ? OK : ts <= 2 ? WARN : BAD);
        } else tTherm.setText("N/A");
        tHz.setText(Math.round(FpsEngine.current(this)) + " Hz");
    }
}
