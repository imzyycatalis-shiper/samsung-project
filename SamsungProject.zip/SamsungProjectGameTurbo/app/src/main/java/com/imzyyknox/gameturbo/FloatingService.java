package com.imzyyknox.gameturbo;

import android.animation.ValueAnimator;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class FloatingService extends Service {
    static boolean running;
    private static final int CY = 0xFF53E9FF, BL = 0xFF3C86FF, PU = 0xFF9270FF, OK = 0xFF55E7A9, WARN = 0xFFFFC857, BAD = 0xFFFF6B6B;
    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView bubble, status, tRam, tBat, tTemp, tTherm, tHz;
    private final ArrayList<TextView> fpsBtns = new ArrayList<>();
    private static final int[] TARGETS = {10, 30, 60, 90, 0};
    private final FpsEngine.Meter meter = new FpsEngine.Meter();
    private LinearLayout panel;
    private View fill;
    private int barW;
    private WindowManager.LayoutParams bp, pp;
    private final ArrayList<TextView> toggles = new ArrayList<>();
    private final Runnable tick = new Runnable() { public void run() { refresh(); ui.postDelayed(this, 2000); } };

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        sp = getSharedPreferences("turbo", MODE_PRIVATE);
        startForeground(7, notification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private Notification notification() {
        String ch = "imzyy_turbo";
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
                new NotificationChannel(ch, "Game Turbo Panel", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, FloatingService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, ch).setContentTitle("IMZYY KNOX Game Turbo")
                .setContentText("Floating hub aktif • tap bubble ⚡")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "STOP", stop).build()).build();
    }

    // ---------- UI helpers ----------
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int c1, int c2, int r, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView txt(String s, int sz, int c, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(c);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }
    private LinearLayout.LayoutParams mt(int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); return p; }
    private LinearLayout.LayoutParams w1(boolean first) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); if (!first) p.leftMargin = dp(6); return p; }
    private WindowManager.LayoutParams lp(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }
    private void status(String s, int c) { if (status != null) { status.setText(s); status.setTextColor(c); } }
    private void open(Intent i) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch (Exception e) { status("Tidak tersedia di perangkat ini", WARN); }
    }

    private TextView tile(LinearLayout r, String label, boolean first) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(0, dp(8), 0, dp(8));
        c.setBackground(bg(0xFF0D1723, 0xFF08121C, 12, 0x2253E9FF));
        TextView l = txt(label, 8, 0xFF8394A9, false); l.setLetterSpacing(.12f);
        TextView v = txt("--", 15, 0xFFFFFFFF, true);
        c.addView(l); c.addView(v);
        r.addView(c, w1(first));
        return v;
    }
    private void btn(LinearLayout r, String s, boolean first, Runnable a) {
        TextView t = txt(s, 10, 0xFFBFF8FF, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(4), dp(11), dp(4), dp(11));
        t.setBackground(bg(0xFF12344B, 0xFF102140, 12, 0x4453E9FF));
        t.setOnClickListener(v -> a.run());
        r.addView(t, w1(first));
    }
    private void toggle(LinearLayout r, String key, String label, boolean first) {
        TextView t = txt(label, 10, 0xFFA4B7CA, true);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(4), dp(11), dp(4), dp(11));
        t.setTag(new String[]{key, label});
        t.setOnClickListener(v -> {
            boolean n = !sp.getBoolean(key, false);
            if (key.equals("dnd")) dnd(n); else if (key.equals("bright")) bright(n); else awake(n);
            paintAll();
        });
        toggles.add(t); paint(t);
        r.addView(t, w1(first));
    }
    private void paint(TextView t) {
        String[] k = (String[]) t.getTag();
        boolean on = sp.getBoolean(k[0], false);
        t.setText((on ? "● " : "○ ") + k[1]);
        t.setTextColor(on ? 0xFF03131C : 0xFFA4B7CA);
        t.setBackground(on ? bg(CY, BL, 12, 0) : bg(0xFF0D1723, 0xFF08121C, 12, 0x33FFFFFF));
    }
    private void paintAll() { for (TextView t : toggles) paint(t); }

    // ---------- Bubble ----------
    private void showBubble() {
        int s = dp(54);
        bubble = txt("⚡", 24, 0xFFFFFFFF, false);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{CY, BL, PU});
        g.setShape(GradientDrawable.OVAL); g.setStroke(dp(2), 0x88FFFFFF);
        bubble.setBackground(g);
        bp = lp(s, s); bp.x = dp(4); bp.y = dp(220);
        int f0 = sp.getInt("fps", -1);
        if (f0 >= 0) FpsEngine.prefer(bp, this, FpsEngine.pick(this, f0));
        applyAwake();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = bp.x; sy = bp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false; bubble.setAlpha(1f); return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                        if (Math.abs(dx) + Math.abs(dy) > dp(6)) moved = true;
                        if (moved) { bp.x = sx + (int) dx; bp.y = sy + (int) dy; try { wm.updateViewLayout(bubble, bp); } catch (Exception x) { } }
                        return true;
                    case MotionEvent.ACTION_UP: if (!moved) openPanel(); else snap(); return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bp);
    }
    private void snap() {
        int w = getResources().getDisplayMetrics().widthPixels, size = dp(54);
        int to = (bp.x + size / 2 < w / 2) ? dp(4) : w - size - dp(4);
        ValueAnimator a = ValueAnimator.ofInt(bp.x, to);
        a.setDuration(220);
        a.addUpdateListener(v -> { bp.x = (Integer) v.getAnimatedValue(); try { wm.updateViewLayout(bubble, bp); } catch (Exception x) { } });
        a.start();
        bubble.setAlpha(.8f);
    }

    // ---------- Panel ----------
    private void openPanel() {
        if (panel != null) return;
        bubble.setVisibility(View.GONE);
        int sw = getResources().getDisplayMetrics().widthPixels;
        int pw = Math.min(dp(300), sw - dp(24));
        barW = pw - dp(28);
        toggles.clear(); fpsBtns.clear();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(14));
        box.setBackground(bg(0xF2101C2C, 0xF2060B13, 24, 0x5553E9FF));

        LinearLayout head = row();
        TextView logo = txt("ϟ", 20, CY, true); logo.setPadding(0, 0, dp(10), 0);
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = txt("IMZYY KNOX", 13, 0xFFFFFFFF, true); t1.setLetterSpacing(.1f);
        TextView t2 = txt("GAME TURBO • FLOATING HUB v3.0", 8, 0xFF8394A9, false); t2.setLetterSpacing(.12f);
        titles.addView(t1); titles.addView(t2);
        head.addView(logo); head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView min = txt("—", 14, 0xFFBFF8FF, true); min.setPadding(dp(12), dp(4), dp(12), dp(4)); min.setOnClickListener(v -> closePanel());
        TextView x = txt("✕", 14, BAD, true); x.setPadding(dp(8), dp(4), dp(4), dp(4)); x.setOnClickListener(v -> stopSelf());
        head.addView(min); head.addView(x);
        head.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            public boolean onTouch(View v, MotionEvent e) {
                if (pp == null) return false;
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = pp.x; sy = pp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE: pp.x = sx + (int) (e.getRawX() - tx); pp.y = sy + (int) (e.getRawY() - ty);
                        try { wm.updateViewLayout(panel, pp); } catch (Exception ex) { } return true;
                }
                return false;
            }
        });
        box.addView(head);

        LinearLayout stats = row();
        tRam = tile(stats, "RAM USED", true); tBat = tile(stats, "BATTERY", false);
        tTemp = tile(stats, "TEMP", false); tTherm = tile(stats, "THERMAL", false);
        box.addView(stats, mt(10));

        FrameLayout track = new FrameLayout(this);
        track.setBackground(bg(0xFF172635, 0xFF172635, 3, 0));
        fill = new View(this); fill.setBackground(bg(CY, PU, 3, 0));
        track.addView(fill, new FrameLayout.LayoutParams(1, dp(6)));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, dp(6));
        tlp.topMargin = dp(8);
        box.addView(track, tlp);

        status = txt("Siap • tap TURBO BOOST", 10, 0xFF8394A9, false);
        box.addView(status, mt(8));

        TextView turbo = txt("⚡  TURBO BOOST", 14, 0xFF03131C, true);
        turbo.setGravity(Gravity.CENTER); turbo.setLetterSpacing(.1f); turbo.setPadding(0, dp(13), 0, dp(13));
        turbo.setBackground(bg(CY, PU, 16, 0));
        turbo.setOnClickListener(v -> boost(0));
        box.addView(turbo, mt(10));

        LinearLayout tg = row();
        toggle(tg, "dnd", "DND", true); toggle(tg, "awake", "AWAKE", false); toggle(tg, "bright", "MAX BRIGHT", false);
        box.addView(tg, mt(10));

        LinearLayout fh = row();
        TextView fl = txt("FPS TARGET", 8, 0xFF8394A9, true); fl.setLetterSpacing(.15f);
        tHz = txt("-- Hz", 12, CY, true);
        fh.addView(fl, new LinearLayout.LayoutParams(0, -2, 1)); fh.addView(tHz);
        box.addView(fh, mt(12));
        LinearLayout fr = row();
        for (int i = 0; i < TARGETS.length; i++) {
            final int tgt = TARGETS[i];
            TextView t = txt(tgt == 0 ? "MAX" : String.valueOf(tgt), 11, 0xFFBFF8FF, true);
            t.setGravity(Gravity.CENTER); t.setPadding(0, dp(10), 0, dp(10));
            t.setOnClickListener(v -> setFps(tgt));
            fpsBtns.add(t); fr.addView(t, w1(i == 0));
        }
        box.addView(fr, mt(6));
        paintFps();

        LinearLayout a1 = row();
        btn(a1, "CLEAN RAM", true, () -> boost(1)); btn(a1, "CLEAR CACHE", false, () -> boost(2)); btn(a1, "PING", false, this::ping);
        box.addView(a1, mt(8));
        LinearLayout a2 = row();
        btn(a2, "DISPLAY", true, () -> open(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        btn(a2, "BATTERY", false, () -> open(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        btn(a2, "OPEN HUB", false, () -> open(new Intent(this, MainActivity.class)));
        box.addView(a2, mt(8));

        TextView foot = txt("Developed by IMZYY KNOX • v3.0", 8, 0xFF52667A, false);
        foot.setGravity(Gravity.CENTER); foot.setLetterSpacing(.1f);
        box.addView(foot, mt(10));

        panel = box;
        pp = lp(pw, -2); pp.x = (sw - pw) / 2; pp.y = dp(90);
        applyAwake();
        box.setAlpha(0f); box.setScaleX(.92f); box.setScaleY(.92f);
        wm.addView(panel, pp);
        box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start();
        meter.start(tHz);
        ui.post(tick);
    }
    private void closePanel() {
        ui.removeCallbacks(tick); meter.stop();
        if (panel != null) { try { wm.removeView(panel); } catch (Exception e) { } panel = null; pp = null; }
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }

    // ---------- Live stats ----------
    private ActivityManager.MemoryInfo mem() {
        ActivityManager.MemoryInfo m = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
        return m;
    }
    private void refresh() {
        if (panel == null) return;
        ActivityManager.MemoryInfo mi = mem();
        int used = (int) (100 - mi.availMem * 100 / Math.max(1, mi.totalMem));
        tRam.setText(used + "%"); tRam.setTextColor(used > 85 ? BAD : used > 70 ? WARN : OK);
        ViewGroup.LayoutParams f = fill.getLayoutParams(); f.width = Math.max(1, barW * used / 100); fill.setLayoutParams(f);
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            int lv = b.getIntExtra("level", 0) * 100 / Math.max(1, b.getIntExtra("scale", 100));
            float t = b.getIntExtra("temperature", 0) / 10f;
            tBat.setText(lv + "%"); tTemp.setText(t + "°"); tTemp.setTextColor(t >= 42 ? BAD : t >= 38 ? WARN : OK);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            int ts = ((PowerManager) getSystemService(POWER_SERVICE)).getCurrentThermalStatus();
            tTherm.setText(ts <= 0 ? "COOL" : ts == 1 ? "WARM" : ts == 2 ? "WARM+" : ts == 3 ? "HOT" : "CRIT");
            tTherm.setTextColor(ts <= 0 ? OK : ts <= 2 ? WARN : BAD);
        } else tTherm.setText("N/A");
    }

    // ---------- Boost features (real, non-root) ----------
    private int killBg() {
        PackageManager pm = getPackageManager();
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        int n = 0;
        for (ResolveInfo r : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName()) || (r.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            am.killBackgroundProcesses(p); n++;
        }
        return n;
    }
    private void boost(final int mode) { // 0 = turbo, 1 = RAM only, 2 = cache only
        status("⚡ Boosting…", WARN);
        new Thread(() -> {
            long before = mem().availMem;
            int n = mode < 2 ? killBg() : 0;
            long kb = 0;
            if (mode != 1) { kb = size(getCacheDir()) >> 10; delete(getCacheDir()); }
            try { Thread.sleep(900); } catch (Exception e) { }
            final long mb = Math.max(0, (mem().availMem - before) >> 20);
            final int fn = n; final long fk = kb;
            ui.post(() -> {
                if (mode == 0) {
                    awake(true);
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    if (nm.isNotificationPolicyAccessGranted() && !sp.getBoolean("dnd", false)) dnd(true);
                    paintAll();
                }
                status("✓ " + fn + " app dirapikan • ~" + mb + " MB bebas • " + fk + " KB cache", OK);
                refresh();
            });
        }).start();
    }
    private void ping() {
        status("📡 Mengetes latency…", WARN);
        new Thread(() -> {
            long best = 9999, tot = 0; int ok = 0;
            for (int i = 0; i < 3; i++) {
                try {
                    long t = SystemClock.elapsedRealtime();
                    HttpURLConnection c = (HttpURLConnection) new URL("https://www.google.com/generate_204").openConnection();
                    c.setConnectTimeout(3000); c.setReadTimeout(3000); c.getResponseCode(); c.disconnect();
                    long d = SystemClock.elapsedRealtime() - t;
                    best = Math.min(best, d); tot += d; ok++;
                } catch (Exception e) { }
            }
            final String m = ok == 0 ? "✕ Tidak ada internet" : "📡 Ping rata-rata " + (tot / ok) + " ms • terbaik " + best + " ms";
            final int col = ok == 0 ? BAD : OK;
            ui.post(() -> status(m, col));
        }).start();
    }
    private void dnd(boolean on) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            sp.edit().putBoolean("dnd", false).apply();
            open(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            status("Izinkan akses DND, lalu tap lagi", WARN); return;
        }
        if (on) {
            sp.edit().putInt("prevf", nm.getCurrentInterruptionFilter()).putBoolean("dnd", true).apply();
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS);
            status("DND aktif (alarm tetap bunyi)", OK);
        } else {
            nm.setInterruptionFilter(sp.getInt("prevf", NotificationManager.INTERRUPTION_FILTER_ALL));
            sp.edit().putBoolean("dnd", false).apply();
            status("DND dikembalikan", 0xFF8394A9);
        }
    }
    private void bright(boolean on) {
        if (!Settings.System.canWrite(this)) {
            sp.edit().putBoolean("bright", false).apply();
            open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            status("Izinkan 'Ubah setelan sistem', lalu tap lagi", WARN); return;
        }
        ContentResolver cr = getContentResolver();
        try {
            if (on) {
                sp.edit().putInt("pb", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                        .putInt("pm", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)).putBoolean("bright", true).apply();
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 255);
                status("Brightness maksimal", OK);
            } else {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, sp.getInt("pb", 128));
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, sp.getInt("pm", 0));
                sp.edit().putBoolean("bright", false).apply();
                status("Brightness dikembalikan", 0xFF8394A9);
            }
        } catch (Exception e) { status("Gagal ubah brightness", BAD); }
    }
    private void paintFps() {
        int sel = sp.getInt("fps", -1);
        for (int i = 0; i < fpsBtns.size(); i++) {
            TextView t = fpsBtns.get(i); boolean on = TARGETS[i] == sel;
            t.setTextColor(on ? 0xFF03131C : 0xFFBFF8FF);
            t.setBackground(on ? bg(CY, PU, 12, 0) : bg(0xFF12344B, 0xFF102140, 12, 0x4453E9FF));
        }
    }
    private void setFps(final int target) {
        final int hz = FpsEngine.pick(this, target);
        if (!FpsEngine.apply(this, hz)) {
            open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
            status("Izinkan 'Ubah setelan sistem', lalu tap lagi", WARN); return;
        }
        sp.edit().putInt("fps", target).apply();
        try {
            FpsEngine.prefer(bp, this, hz); wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) { FpsEngine.prefer(pp, this, hz); wm.updateViewLayout(panel, pp); }
        } catch (Exception ignored) { }
        paintFps(); status("Menerapkan " + hz + " Hz…", WARN);
        ui.postDelayed(() -> { String m = FpsEngine.verify(this, target, hz); status(m, m.startsWith("✓") ? OK : WARN); }, 900);
    }
    private void awake(boolean on) { sp.edit().putBoolean("awake", on).apply(); applyAwake(); }
    private void applyAwake() {
        boolean on = sp.getBoolean("awake", false);
        for (WindowManager.LayoutParams p : new WindowManager.LayoutParams[]{bp, pp}) {
            if (p == null) continue;
            if (on) p.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON; else p.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        }
        try {
            if (bubble != null && bubble.isAttachedToWindow()) wm.updateViewLayout(bubble, bp);
            if (panel != null && pp != null) wm.updateViewLayout(panel, pp);
        } catch (Exception ignored) { }
    }

    private long size(File f) { if (!f.exists()) return 0; if (f.isFile()) return f.length(); long n = 0; File[] a = f.listFiles(); if (a != null) for (File x : a) n += size(x); return n; }
    private void delete(File f) { if (!f.exists()) return; if (f.isDirectory()) { File[] a = f.listFiles(); if (a != null) for (File x : a) delete(x); } if (!f.equals(getCacheDir())) f.delete(); }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "STOP".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }
    @Override public void onDestroy() {
        running = false;
        ui.removeCallbacks(tick); meter.stop();
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception e) { }
        try { if (panel != null) wm.removeView(panel); } catch (Exception e) { }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
